/*
 * File: netest2_initialize.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 17:06:25
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "netest2.h"
#include "netest2_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void netest2_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for netest2_initialize.c
 *
 * [EOF]
 */
