/*
 * File: netest2_initialize.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 17:06:25
 */

#ifndef NETEST2_INITIALIZE_H
#define NETEST2_INITIALIZE_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "netest2_types.h"

/* Function Declarations */
extern void netest2_initialize(void);

#endif

/*
 * File trailer for netest2_initialize.h
 *
 * [EOF]
 */
