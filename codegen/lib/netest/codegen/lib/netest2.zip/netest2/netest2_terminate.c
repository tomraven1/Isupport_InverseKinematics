/*
 * File: netest2_terminate.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 17:06:25
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "netest2.h"
#include "netest2_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void netest2_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for netest2_terminate.c
 *
 * [EOF]
 */
