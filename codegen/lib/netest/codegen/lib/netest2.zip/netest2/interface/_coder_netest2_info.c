/*
 * File: _coder_netest2_info.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 17:06:25
 */

/* Include Files */
#include "_coder_netest2_info.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char * data[24] = {
    "789ced5d4d8c1c4715ae25b60987e0900b0ebf9e082282d18e710442489176b3decd2ef1da9bf50f4e6cabddd353335372f50fdd3dcb98d32896d08a13e2c409"
    "21714148b9e7829440924b908244a2dc39200edc919040544d4fef74d7f64e95bbab667a67df4ab3b36fa7aafafd7dfddeab9f1eb4b4b58dd8cfe7d92bf81742",
    "67d8fb93ecf51994fc9c1ed34becb53d7e4ffe7f0a3d35a6df642fc7f7623c88930f3ddbc528fd69fb2ef16c2fbef130c028c4914ff7707bf44987507c83b8f8"
    "8a9f21360923dc8dcc470704ff28ec450723239a25921f2ec7afd1448e530572b433723c3da6efacdf5bfb61f36684c3a819fb6ef315dfef527cfe7248f67033",
    "226e9fda31f1bda8b9bd7ae3caeacbd665ecfad6def79a8edfc65dec352969353d1ce3281ebf5d5a761bae1d30d95d7b60d941401fa6fcfd40c2df19813f4eb7"
    "a241a7ef25fd5724fdcf0afd39cd3a3b5c00ab677b6d8a47e30c25e3fc481887d377b6aedc1ea96a27f4bba1ed9ee7c649b5d2dcbd74f1bbdfb799027ddaf207",
    "4decd291625c3ba676ab8929fba39948b2ec4eec95d5c799023e96327c7c6efc7fc6fd7b979efd64b57cffaad7d7d7ff5b99fe4b05fd51e6bd4cfb5fa2e976be"
    "8bf276e6b43e3b37923f2cc7770386a116c5295f3b12bebe26f0c56976298b78b1d5f143eafb81e5efe1b043fd9f5a4e0f3b0f92712f4e1937fdc98eabaaa7fb",
    "42bffb55f5c4c8e9f22cbb15f0f13ee043adfddb68badd7f8ef276e7b469bb37a637b07a98063894fbfbd2f87f13fe4f21127508efb729e9f745416e4ef37817"
    "2e33c670e8d994fdd1c6832d2f1ef131908cb7218cb751568f1d32c0edc0675c34b92c3c9654f0b33f034ed4dacfdbbe2b92eb3f255c9fd324f2fa2e0e8913f3",
    "f4b31c5e9c9e1daae44bd784eb5fd3227f867fa608f0738807b27850a6be6043b33ac52c3eccd41309e7d5eb0904f99262fb938a0fe21d577c100df536e043b5"
    "fd10cdc3ce87e755647efa448e8f27100f0026ea02993eb684f1b62aeaa36dc7365345331316aaf8cd2ffed902bfd7e1f7b3b2b3cc7fcf097c705af05fcf0ebb",
    "c4737a0f4cce27559e778b5860c1edd11c7438fe7d61fc964ad23c9024515185f9a4b7ceed7e0c3850687f1cec5ec4d769812f4eb314ca0f15fb17e54d6dbf3f"
    "9af19dc7fd01537e771849a0230e7c7af1798803758c0347d959b6bef075810f4e8b794cf4729fd078cbbb9accc268c1c1bea4ff6da1ffed32fae1af43370551",
    "9c2aeb0be8effffb0bc48345c2c397053e382de021726c6a87cb6954a8b6de26c3c14da1dfcd327a29c4c185448e8c8e2ae445ef405d7cbc70705fc2c70b021f"
    "9c167030dacf717de4441be39d155bde0eb51d9cb9ce8ae43aaafb3464fb595ac238ad327a2bc4c9d1626a984fdaffe845c08d4afbbadbdf545c319d67417c59",
    "2c9c0cd16ce34bd9f92785f9539778d7c2edf17caca9f5861d818f9d32fa28f4ff94fd4af5c5bf5f6a83dfebf0fb59d959e6f730ef0af3aef39c77bd87f276e7"
    "b46e1c8cd6a1f1200eb1db4fe33ee0027051e7fac14679bb73da082e5ac4cb6223e54f43be94e4dbebddb9ac5f9b8bafa95895f2a83f7d780df2a87ae751793b",
    "af48f850dde73a6b1cc0fe57c081a9fb5d111f4f0a7c709aef1767e5796f1efeaf6d5f97b0ff9dcba361be15fc5fb1fd3e9a6e6773ebb313ff6f744818c5c939"
    "1d382707e7e40017877101e7de201e40fdac6dfd0d0f82554a7de7605cdd3891dd3f6e08e3ddd0a6c7ac7855e79dd0bb801b3df162d6f6be2de1e739811f4e4f",
    "c1c9557f2dc9a5d2f175e3459667dd11c6bb63447f6331c70548853ceb0f3f3e05b8d1116f7a286f774e1b893749da950b3b305f0bf3b58013359c98da7f3eeb"
    "bc0cf6a32f166e8668babd67753e15e6b5605e0bf030e143775e65fabc1ee45127c3ff8fdbbab769bf87756ef0fb3aad739bf67758d75e0c7f9f5f9da777fdae",
    "aabfc37addc9f6f3c2750703cfff2ed297aabf863860b7c7d9e43366ea9b44020df7f7e77e6581dfebc8676665e74d091f70dea1d47c0e9c77506c3f44f5c081"
    "6cbdb921f0c169f13903118b48f12d9b92f675f233bc1a768fb04399b820c3c71b42ff37cae8a9f85cf921b1347c1fc47faf5e8638a1d2beae7637b55e66fa39",
    "02b03eb658f890ad2b6394b737a7cde1a34122fe391b9416e8af88bfd3027f9ce6837414fb57ad27f43fc767f41c632e818ee7f8c1ba9862fb21aa879d212e40"
    "5ca8031e6a18175a7edf6b47480d275f15f8e3f4219c6cf15883c335caae89e4fb2996d0d1cf9f91e1e396c0cf2d6dfaca8b516dde159ebfb428f82873bf87ef",
    "45817ce9a4fb3f7cef09f8ff22f8bf2c3ffa8ac01fa78fd837bd8ba91fa472d776bfa9cafa444ea24afb4d1f7dc3039ca8b47f1b4db7fb2394b73ba74ddbbdd1"
    "a1be1d5b0ecf972dfe65de36f1222b6d9456036a387a56e09fd3028e4657db66ffa319bd98aa3376057e761f579f47de7726626858bf803a43b1fdefd1747b0f",
    "50dede9c368e1f125911e97ab89d070de45d907799c6435dd7f3c0efc1efc1ef0ff305f34ce0f755fc7e88e661e7c3fb9b647e0adf2faae437f0fda28aed87a8"
    "1e7e0fe796e1dc32e061c28786fb399c5b4607fe03e79615dbcf24ff3fd2ff1bd4772e13375a0df1ba1bc40f277c417c80f850077c0cd1c2c48720f4db11abb4",
    "8dd6c7e6e242ca7ea5b8f0cda575d8a7a7d27e1f4db7f3accf7fcafcff0b023f9ce6f74f37262e8eac1ea6010e33f2958d0332bd5c17fa71bacafdc00fa2e621"
    "39aa3f47f203b8ffabb597edc7b051dede9c3660ef86e3bbaeef25913fcaf007fbba615f771d7052b7fba2867c09ea6904f5f471c781867d462d6a47cb832e76",
    "b3f3f4a6f61969d14f210e2e70399a2339aae74f2b9fbc0978a80d1e1ec3de323c7c49e087d34578201e251e9ec869aa9e30f77cff443f891c95bfcfe1afff18"
    "429eb4887850a81f4678e847d80a7187ff6d749ef575a1dfeb9af5939143c7ba34e042b17ddd7001f503d40f80032de77dd2dbe9410961b27e30771efac2588e",
    "898a2ad40f7f8c1e001e54da979a7f35b00ed1886d2f225dcb0e02fa30c39f2c4ec0ba04ac4b9c445c3ceebe563c08b4e4490349ff5784fe9caeb65ecf77b132"
    "eeab3d6ffed38bcf83dfabb49fb77d35cca72609f532f7f8895cb5beef17e743891c63dda4fcc0b9cdc5f6fffb92ebbf205c9fd3e2f35879a8b83e729e8dbee7",
    "f090b3e5ed50dbc119395724d7392b5c87d39df16856cff6da142bc5c996304eab8cbe8acf371d29a686733efb1fbd0878d19127cddbfeb278a2f0bcb17e8477"
    "ecb0e3876b2c778bd171adaff36254acafaffee6db800f95f675b3f7a6849f73023f9c3e0a0f26f3aad7847eafe9d78b86f587e1d9fd478083931027e03c049c",
    "87009c98abcf4def87853afd64e1c446797b737a96f3b3327ffeacc01fa7c336d9236d3c93f56cddcf1be0eb1563fe75e455ebffd9011ca8b41fa27ad819ce49"
    "c03909c0c3840f191ece0b7c70ba204f6249c59aef062c2e318fd68187f9edff3b248e8efd7fef42be74bc70b129e1e319810f4e0bb860a316ebdd449ef4aad0",
    "ffd5327a29c40313a37abdf012e4497aea850ecadb99d346ea05d70e5ce2b9f6c00af11e1b1997f7e35634e8f43dbdeb7943c938669ec79048a2e1f9c4ef413c"
    "38197890d5cf65e75d8792eb42ddbc18fe3f44f5bbcfc13c11f8bb297f3f0e759faaff9308ffa46fd3e393ff177c7fe44882eaf9ffef3ef8cedfc0ff15da0f51",
    "3decbc22e1e369810ffe1aadcb2623598e1fce641ee89ed0ffde581f3bd51412b05cd18e71531469a4a10a7ef4cefb70fe4d4b1c9897dd37257c29ec4bf2ecb0"
    "4b3ca7f7c0e4be8bbb42bfbbc8c0f7b61c4852f5b901c3b7ceedc2ba814afbdfa2e976a7286f774e1bc545232593ed05457a2ce2f3b4c027a749e4d99e62ffba",
    "d50b691c6512c0f7aa67facf3b5f9a959d615d19d695e78d87ff03dd1d0c63", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(data, 60544U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xResult;
  mxArray *xEntryPoints;
  const char * fldNames[4] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs" };

  mxArray *xInputs;
  const char * b_fldNames[4] = { "Version", "ResolvedFunctions", "EntryPoints",
    "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 4, fldNames);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name", mxCreateString("netest2"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", mxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", mxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  xResult = emlrtCreateStructMatrix(1, 1, 4, b_fldNames);
  emlrtSetField(xResult, 0, "Version", mxCreateString("9.0.0.341360 (R2016a)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_netest2_info.c
 *
 * [EOF]
 */
