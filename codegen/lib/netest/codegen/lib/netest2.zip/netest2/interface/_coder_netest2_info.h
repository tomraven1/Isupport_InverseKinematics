/* 
 * File: _coder_netest2_info.h 
 *  
 * MATLAB Coder version            : 3.1 
 * C/C++ source code generated on  : 24-Apr-2017 17:06:25 
 */

#ifndef _CODER_NETEST2_INFO_H
#define _CODER_NETEST2_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif
/* 
 * File trailer for _coder_netest2_info.h 
 *  
 * [EOF] 
 */
