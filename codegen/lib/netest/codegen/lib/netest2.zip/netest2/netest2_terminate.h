/*
 * File: netest2_terminate.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 17:06:25
 */

#ifndef NETEST2_TERMINATE_H
#define NETEST2_TERMINATE_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "netest2_types.h"

/* Function Declarations */
extern void netest2_terminate(void);

#endif

/*
 * File trailer for netest2_terminate.h
 *
 * [EOF]
 */
