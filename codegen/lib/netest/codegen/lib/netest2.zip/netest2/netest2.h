/*
 * File: netest2.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 17:06:25
 */

#ifndef NETEST2_H
#define NETEST2_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "netest2_types.h"

/* Function Declarations */
extern void netest2(const double x1[12], double b_y1[6]);

#endif

/*
 * File trailer for netest2.h
 *
 * [EOF]
 */
