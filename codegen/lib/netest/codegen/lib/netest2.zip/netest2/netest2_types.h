/*
 * File: netest2_types.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 17:06:25
 */

#ifndef NETEST2_TYPES_H
#define NETEST2_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for netest2_types.h
 *
 * [EOF]
 */
