/*
 * File: _coder_netest_info.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 16:05:07
 */

/* Include Files */
#include "_coder_netest_info.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char * data[24] = {
    "789ced5dcd8f1c4715af25b60987e0900b0e9f9e082282d1b6490442489176b3decd2ef1da9bf5da38b1ad764f4fcd4ec9fd4577cf32e6348a25b4e284387142"
    "485c1052eeb9203990e412a4209128770e08893f00090944d5f4f44e774def5479aa6aa677fc469add7d3b55d5efebd7efbdfae8414b5bdb88be3e4fdf0fff85",
    "d019fafb49fafe0cca5ea787f4127d6f0f7f67ff3f859e1ad26fd1b71b0629eea5d98781e36394bf5aa14f022748f7ee4718c53809bd03dc1a7cd2261ede233e"
    "be1c16884d42097fa3f0d111c13e8a3bc9d1c8c82b12d98bc9d14723394e55c8b15390e3e9217d6bfdceda0fadeb098e132b0d7debd530dcf7f0f94b3139c056",
    "42fcaee7a4240c126b7b75eff2ea2bf625ec87f6c1f7ac00a7384997fd86ef44544edfe9d94e1479f7191f3f10f07186e383d1cda4d7ee06991c2b82fe67b9fe"
    "8ca69d5dc6a8dd71829687a5f4f1236e1c46dfdaba7c73a0929d38dc8f1dff3c33422ebdb5fbe2c5ef7edfa18a0abd66d8b3b0ef591e695abe937a4ed3c21efd",
    "c3ca2459f6477629eae34c051f4b053e3e37fc3fe5febd179ffd6475fafeaad7d7d7ff5b85fe4b15fd51e1f734ed7f8926dbf9362adb99d1faecdcc8feb0ddd0"
    "8f28569a1ecef9da11f0f5358e2f46d34bd92448ed76187b6118d9e1018edb5ef853dbed60f75e36eec509e3e6afe2b8b27abacbf5bbabaa274a4e9667d957c0",
    "c7fb800fb9f6efa0c976ff392adb9dd1a6edde98dcc0ee602fc2b1d8df9786ff1bf17f0a91a44d58bf4d41bf2f727233da0d5b385ea68ce138703cfa470bf7b6"
    "8274c0474f30de0637dec6b47a6c931e6e4521e5c262b2b058a2e0677f069cc8b59fb77d5704d77f8abb3ea34912747d1c13376569e67478713b4e2c932f5de5",
    "ae7f558bfc05fea922c0cf211e88e2c134f5051d9ad62866f161a69ec83857af2710e44b92ed1f577c90e0a4e28368a8b7011fb2edfb681e761e9f5711f9e913"
    "253e9e402c0098a80b44fad8e2c6db52d447cb491daa0aab101654fce617ff6c82dfebf0fb59d959e4bfe7383e18cdf96fe0c4fb24703bf74cce2729cfbb2534",
    "b0e09635e07df8f3c2f0572e89752449a62285f9a4b7cfed7e0c3890687f12ec5ec5d7698e2f46d3142a8c25fb57e54dadb03b98f19dc7fd017becee30904047"
    "1cf8f4e2f31007ea18078eb3b3687de1eb1c1f8ce6f398e4952ef1d2ade04a360ba305078782fe37b9fe37a7d10f7b8fdd14787154d617d0dffff71788078b84",
    "872f737c309ac343e23a9e132fe751416dbd4d8483eb5cbfebd3e8a512071732390a3a52c88b1e425d7cb2707057c0c70b1c1f8ce67030d8cb716de0441bc39d"
    "155bc18ee7b8b8709d15c17564f769fc5a304e931ba7398dde2a7172bc981ae6930e3f7a097023d3beeef63715574ce759105f160b277d34dbf832edfc93c4fc",
    "a94f82abf1f6703ed6d47a43e57e472dfe9fb3af545ffcfbe516f8bd0ebf9f959d457e0ff3ae30ef3acf79d73ba86c7746ebc6c1601d1af7d218fbdd3cee032e"
    "001775ae1f1c54b63ba38de0a24982223672fe34e44b59bebdbe3f97f56b73f135174b298ffad38757218faa771e55b6f38a800fd97daeb3c601ec7f051c98ba",
    "df55f1f124c707a3d97e715a9e77e6e1ffdaf67571fbdf993c1ae65bc1ff25db1fa2c97636b73e3bf2ff469bc4499a9dd3817372704e0e70318e0b38f706f100"
    "ea676deb6fb817ad7a5ee81e8dab1b27a2fbc71e37de9e363d16c5539d7742ef026ef4c48b59dbfba6809fe7387e183d012757c2b52c97cac7d78d17519e758b",
    "1bef9611fd0dc51c16200a79d61f7e7c0a70a323de7450d9ee8c36126fb2b4ab147660be16e66b0127723831b5ff7cd67919ec475f2cdcf4d1647bcfea7c2acc"
    "6bc1bc16e061c487eebccaf4793dc8a31e0fff3f69ebdea6fd1ed6b9c1efebb4ce6ddadf615d7b31fc7d7e759edef53b557f87f5bac5f6f3084db6ef0a2adb97",
    "d1aacff99ed62f631cd1dbe06cf21633754c268186fbf873bfb2c1bf75e42db3b2f3a6800f38d730d5bc0d9c6b906cdf47f5c081685db9c1f1c168fe7902098d"
    "3ce90dc723ad6be4677835de3fc60ed3c405113edee4fabf398d9eaacf8f8f89a5e17b1ffe7be512c40999f675b5bba97531d3cf0b8075b0c5c28768fd18a3b2",
    "bd196d0e1f0d92b0cfe9a05e85feaaf83bcdf1c76836485bb2bf6a3da1ff793d83e7153309743caf0fd6bf24dbf7513dec0c7101e2421df050c3b8d00cbb412b"
    "417238f92ac71fa3c770b2c5620d8ed73c7a4d24de37b1848e7fce8c081f37387e6e68d357590cb5f95578ced2a2e0639afb3d7cff09e44b8fbbffc3f79b80ff",
    "2f82ff8bf2a3af70fc31fa98fdd1bbd80ba35ceedaee2b95599f2849a4b4aff4c13702c0894cfb77d064bb3f4065bb33dab4dd1b6d2f7452db65f9b2cdbe9cdb"
    "214162e78df26a400e47cf72fc339ac3d1e06adbf47f5e412fa6ea8c5d8e9fdd47d5e7b1f79d91181ad62fa0ce906cff7b34d9de3d54b637a38de387247642f6",
    "03dc2a8306f22ec8bb4ce3a1aeeb79e0f7e0f7e0f7e37cc13c13f8bd8adff7d13cec3cbebf49e4a7f03da2527e03df232ad9be8feae1f7703e19ce27031e467c"
    "68b89fc3f96474e43f703e59b2fd4cf2ff63fdbfe185ee25e227ab315ef7a3f4fe882f880f101fea808f3e5a98f810c5612ba195b6d1fad85c5cc8d9578a0bdf",
    "5c5a877d7a32ede775ce53e4e75fe0aecb68769ff453e2e3c4ee602fc271418e69eff787023eae71fd18ad82fb304aac3139d49f0bf901dce7e5da8bf65d38a8"
    "6c6f461bb077c30d7d3f0cb2089f14f883fddbb07fbb0e38a9db7d51435e04753382baf9a4e340c37ea2a6e724cbbd7dec17e7e34ded27d2a29f4a1c5c607258",
    "0339d4f3a7954fde023cd4060f8f606f111ebec4f1c3e82a3c90c023011ec969aa9e30f7bcfe4c3f991ccadfcff0d77ff4214f5a443c48d40f033c74136cc7b8"
    "cdfe363a9ffa06d7ef0dcdfa29c8a163fd197021d9be6eb880fa01ea07c08196733df9edf4a88430593f983bf77c6128c748450af5c31f937b800799f67d34d9",
    "dedba86c6f46abae3734522748c8beed4491771fc9c503587f80f58745f6ff47dd8f8a7b9196bca727e8ff2ad79fd16aebec6cf729e55eed79f09f5e7c1efc5b"
    "a6fdbcedab617e344b909799c78fe4aaf5fdbd3abfc9e418ea26e707ce5b2eb6ffdf155cff05eefa8ce69fa3cac2c4b581f36c7403978596ad60c7735c5c9073",
    "45709db3dc7518dd1e8e66779ca0e561a9f5f826374e731a7d559f4b3a564c0de7730e3f7a09f022d3beeef617c51389e7847513bce3c4ed305ea3395a8a4e6a"
    "bd5c1643b15ebef29b6f033e64dad7cdde9b027ece71fc30fa383c98ccab5ee7fabdae5f2f1ad613fa670f1f000e1e873801e718e01c03e0c45c7d6e7a7f2bd4",
    "e98b85933e9a6cef59cdc38afcf6b31c1f8c8e5be480b4f04cd6a1753f0f80ad3f0cf9d7913fadff6707fc5d87bfcfcace70be01ce37001e467c88f0709ee383"
    "d115f9104d1ed6423fa2f1877ab40e3ccc6fdfde98383af6edbd0b79d1c9c2c5a6808f67383e18cde1828e5aad771379d26b5cffd7a6d14b251ea818ea75c1cb",
    "9027c9b517e50195cfc755ad0b7c27f249e03b3d3bc60774145cad2f59bf6d26bd7637d0bb4ed7178c63e6f90899241a9e17fc1edcff17d3ff45f5f1b4f3a77d"
    "c175a12e5e0c7fefa3faddd7601e08fcdd94bf9f84ba4ed6ff49827fd275bc9393df577c7fe34002f5fcfe771f7ce76fe0ff12edfba81e765e11f0f134c7077b",
    "0fd657b3916c378c6732cf7387eb7f67a88f1d358544343774526cf1220d34a4e0470fdf8773695ae2c0bcecbe29e04b627f51e0c4fb24703bf74cee9fb8cdf5"
    "bb8d0c7c6fca9124aae7f9fb6f9fdb85750199f6bf4593edeea1b2dd196d14178d9cccb60954e9b18acfd31c9f8c2649e00492fdeb562fe471944a00df6b5ee8",
    "3fef7c69567686756358379e371efe0f2e92cfc3", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(data, 60368U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xResult;
  mxArray *xEntryPoints;
  const char * fldNames[4] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs" };

  mxArray *xInputs;
  const char * b_fldNames[4] = { "Version", "ResolvedFunctions", "EntryPoints",
    "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 4, fldNames);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name", mxCreateString("netest"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", mxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", mxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  xResult = emlrtCreateStructMatrix(1, 1, 4, b_fldNames);
  emlrtSetField(xResult, 0, "Version", mxCreateString("9.0.0.341360 (R2016a)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_netest_info.c
 *
 * [EOF]
 */
