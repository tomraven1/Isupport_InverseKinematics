/* 
 * File: _coder_netest_info.h 
 *  
 * MATLAB Coder version            : 3.1 
 * C/C++ source code generated on  : 24-Apr-2017 16:05:07 
 */

#ifndef _CODER_NETEST_INFO_H
#define _CODER_NETEST_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif
/* 
 * File trailer for _coder_netest_info.h 
 *  
 * [EOF] 
 */
