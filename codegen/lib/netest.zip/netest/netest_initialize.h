/*
 * File: netest_initialize.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 16:05:07
 */

#ifndef NETEST_INITIALIZE_H
#define NETEST_INITIALIZE_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "netest_types.h"

/* Function Declarations */
extern void netest_initialize(void);

#endif

/*
 * File trailer for netest_initialize.h
 *
 * [EOF]
 */
