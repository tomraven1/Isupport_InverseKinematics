/*
 * File: netest.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 16:05:07
 */

#ifndef NETEST_H
#define NETEST_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "netest_types.h"

/* Function Declarations */
extern void netest(const double x1[15], double b_y1[9]);

#endif

/*
 * File trailer for netest.h
 *
 * [EOF]
 */
