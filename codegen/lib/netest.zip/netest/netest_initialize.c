/*
 * File: netest_initialize.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 16:05:07
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "netest.h"
#include "netest_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void netest_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for netest_initialize.c
 *
 * [EOF]
 */
