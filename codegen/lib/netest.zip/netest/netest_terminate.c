/*
 * File: netest_terminate.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 16:05:07
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "netest.h"
#include "netest_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void netest_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for netest_terminate.c
 *
 * [EOF]
 */
