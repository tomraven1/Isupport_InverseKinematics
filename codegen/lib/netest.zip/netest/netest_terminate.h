/*
 * File: netest_terminate.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 24-Apr-2017 16:05:07
 */

#ifndef NETEST_TERMINATE_H
#define NETEST_TERMINATE_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "netest_types.h"

/* Function Declarations */
extern void netest_terminate(void);

#endif

/*
 * File trailer for netest_terminate.h
 *
 * [EOF]
 */
